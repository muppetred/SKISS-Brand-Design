repo: muppetred/SKISS-Brand-Design
branch: main

## Last sync
date: 2026-10-23T22:49:35Z

### Updated in this project
- Import complet : tokens, composants, kits, cartes, gabarits
- Polices Khand et Hind auto-hébergées dans fonts/
- Vignette du système refaite (aplat brûlé, nuances du clair au foncé)

## Screen map
| Écran | Fichiers du dépôt |
|---|---|
| Deck 16:9 | ui_kits/deck/*.jsx, ui_kits/deck/index.html, ui_kits/deck/deck-overview.html |
| Réseaux sociaux | ui_kits/social/*.jsx, ui_kits/social/*.html |
| Documents | ui_kits/documents/* |
| Site web | ui_kits/website/*.jsx, ui_kits/website/site.css, ui_kits/website/index.html |
| Gabarits v2 | templates/skiss-v2-carrousel, templates/skiss-v2-site, templates/skiss-v2-slides |
| Composants | components/core, components/brand, components/blocks |
| Fondations | tokens/*.css, guidelines/*.html |
